# Real Trust - Business Consultation Website

A complete full-stack web application with simple Java backend and vanilla JavaScript frontend for business consultation services.

## Project Structure
```
/backend                    - Backend Server (2 options)
  ├── SimpleAgencyServer.java - Simple Java HTTP Server (ACTIVE)
  ├── run.bat               - Start simple server script
  ├── pom.xml               - Spring Boot configuration (alternative)
  └── src/                  - Spring Boot structure (alternative)
/frontend                   - HTML/CSS/JavaScript frontend
  ├── index.html            - Landing page
  ├── admin.html            - Admin panel
  └── css/style.css         - Styling
```

## Features Implemented

### 🏠 Landing Page (index.html)
- **Hero Section**: Professional banner with "Consultation • Design • Marketing"
- **About Section**: Company description and services
- **Our Projects Section**: 
  - Fetches all projects from backend
  - Displays: Project Image, Name, Description
  - Non-functional "Read More" button
- **Happy Clients Section**:
  - Fetches all clients from backend  
  - Displays: Client Image, Description, Name, Designation
- **Contact Form**:
  - Fields: Full Name, Email, Mobile, City
  - Submits to backend with validation
- **Newsletter Subscription**:
  - Email subscription with backend integration

### 🔧 Admin Panel (admin.html)
- **Project Management**:
  - Add new projects (Name, Image URL, Description)
  - View all projects in table format
- **Client Management**:
  - Add new clients (Name, Image URL, Designation, Description)
  - View all clients in table format
- **Contact Form Data**:
  - View all contact submissions
  - Display: Name, Email, Mobile, City
- **Newsletter Subscribers**:
  - View all subscribed email addresses

## Setup Instructions

### 1. Backend Setup

**Option A: Simple Java Server (Recommended - No setup needed)**
```bash
cd backend
run.bat
```

**Option B: Spring Boot (Alternative - Requires Maven)**
```bash
cd backend
mvn clean install
mvn spring-boot:run
```

Backend runs on: http://localhost:8080

### 2. MongoDB Setup (Optional - for Spring Boot version)
1. Create account at [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create a free cluster
3. Get connection string
4. Update `backend/src/main/resources/application.properties`

### 3. Frontend Setup
1. Open `frontend/index.html` in browser for landing page
2. Open `frontend/admin.html` in browser for admin panel
3. Or serve via HTTP server:
```bash
cd frontend
python -m http.server 3000
```

## API Endpoints

### Projects
- `GET /projects` - Get all projects
- `POST /projects/add` - Add new project

### Clients  
- `GET /clients` - Get all clients
- `POST /clients/add` - Add new client

### Contact
- `GET /contact` - Get all contact submissions (admin)
- `POST /contact/add` - Submit contact form

### Newsletter
- `GET /newsletter` - Get all subscribers (admin)
- `POST /newsletter/add` - Subscribe to newsletter

## Database Collections
- `projects` - Project data
- `clients` - Client testimonials
- `contact_submissions` - Contact form data
- `newsletter_subscribers` - Email subscriptions

## Technologies Used
- **Backend**: Java (Simple HTTP Server) / Spring Boot 3.2 (alternative)
- **Frontend**: HTML5, CSS3, Bootstrap 5, Vanilla JavaScript
- **Database**: In-memory storage (Simple server) / MongoDB Atlas (Spring Boot)
- **Validation**: Basic validation

## Deployment Options
- **Backend**: Heroku, Railway, Render, AWS
- **Frontend**: Netlify, Vercel, GitHub Pages
- **Database**: MongoDB Atlas (already cloud-based)

## Project Features Summary
✅ Responsive landing page with modern design  
✅ Dynamic content loading from backend  
✅ Admin panel for content management  
✅ Contact form with validation  
✅ Newsletter subscription system  
✅ Professional styling with Bootstrap  
✅ MongoDB data persistence  
✅ CORS enabled for development  
✅ Clean, maintainable code structure