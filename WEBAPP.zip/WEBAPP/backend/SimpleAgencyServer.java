import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.util.*;

public class SimpleAgencyServer {
    private static List<String> projects = new ArrayList<>();
    private static List<String> clients = new ArrayList<>();
    private static List<String> contacts = new ArrayList<>();
    private static List<String> newsletters = new ArrayList<>();
    
    static {
        // Initialize with sample data - smaller, optimized images
        projects.add("{\"id\":\"1\",\"name\":\"E-Commerce Website\",\"description\":\"Modern online store with payment integration\",\"image\":\"https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=350&h=200&fit=crop\"}");
        projects.add("{\"id\":\"2\",\"name\":\"Mobile Banking App\",\"description\":\"Secure mobile banking solution\",\"image\":\"https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=350&h=200&fit=crop\"}");
        projects.add("{\"id\":\"3\",\"name\":\"Corporate Branding\",\"description\":\"Complete brand identity package\",\"image\":\"https://images.unsplash.com/photo-1542744094-3a31f272c490?w=350&h=200&fit=crop\"}");
        projects.add("{\"id\":\"4\",\"name\":\"Restaurant Website\",\"description\":\"Food ordering and reservation system\",\"image\":\"https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=350&h=200&fit=crop\"}");
        
        clients.add("{\"id\":\"1\",\"name\":\"John Smith\",\"description\":\"Outstanding work! They transformed our business completely.\",\"designation\":\"CEO, TechCorp\",\"image\":\"https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop&crop=face\"}");
        clients.add("{\"id\":\"2\",\"name\":\"Sarah Johnson\",\"description\":\"Professional team with excellent communication skills.\",\"designation\":\"Marketing Director\",\"image\":\"https://images.unsplash.com/photo-1494790108755-2616b612b786?w=80&h=80&fit=crop&crop=face\"}");
        clients.add("{\"id\":\"3\",\"name\":\"Mike Davis\",\"description\":\"Exceeded expectations in every aspect of the project.\",\"designation\":\"CTO, StartupXYZ\",\"image\":\"https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&crop=face\"}");
        clients.add("{\"id\":\"4\",\"name\":\"Emily Chen\",\"description\":\"Creative solutions that perfectly matched our vision.\",\"designation\":\"Founder, DesignStudio\",\"image\":\"https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop&crop=face\"}");
    }
    
    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        
        // Project endpoints
        server.createContext("/projects", new ProjectHandler());
        server.createContext("/clients", new ClientHandler());
        server.createContext("/contact", new ContactHandler());
        server.createContext("/newsletter", new NewsletterHandler());
        
        server.start();
        
        System.out.println("=================================");
        System.out.println("🚀 Agency Backend Server Started!");
        System.out.println("=================================");
        System.out.println("Server URL: http://localhost:8080");
        System.out.println("Endpoints available:");
        System.out.println("  GET  /projects");
        System.out.println("  POST /projects/add");
        System.out.println("  GET  /clients");
        System.out.println("  POST /clients/add");
        System.out.println("  GET  /contact");
        System.out.println("  POST /contact/add");
        System.out.println("  GET  /newsletter");
        System.out.println("  POST /newsletter/add");
        System.out.println("=================================");
        System.out.println("Press Ctrl+C to stop the server");
        System.out.println("=================================");
    }
    
    static class ProjectHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            addCORSHeaders(exchange);
            
            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();
            
            if ("OPTIONS".equals(method)) {
                exchange.sendResponseHeaders(200, 0);
                exchange.close();
                return;
            }
            
            if ("GET".equals(method) && "/projects".equals(path)) {
                String response = "[" + String.join(",", projects) + "]";
                sendResponse(exchange, 200, response);
            } else if ("POST".equals(method) && "/projects/add".equals(path)) {
                String body = readRequestBody(exchange);
                // Simple JSON parsing
                String id = String.valueOf(System.currentTimeMillis());
                String newProject = body.replaceFirst("\\{", "{\"id\":\"" + id + "\",");
                projects.add(newProject);
                sendResponse(exchange, 200, newProject);
                System.out.println("✅ New project added: " + extractName(body));
            } else {
                sendResponse(exchange, 404, "{\"error\":\"Not Found\"}");
            }
        }
    }
    
    static class ClientHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            addCORSHeaders(exchange);
            
            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();
            
            if ("OPTIONS".equals(method)) {
                exchange.sendResponseHeaders(200, 0);
                exchange.close();
                return;
            }
            
            if ("GET".equals(method) && "/clients".equals(path)) {
                String response = "[" + String.join(",", clients) + "]";
                sendResponse(exchange, 200, response);
            } else if ("POST".equals(method) && "/clients/add".equals(path)) {
                String body = readRequestBody(exchange);
                String id = String.valueOf(System.currentTimeMillis());
                String newClient = body.replaceFirst("\\{", "{\"id\":\"" + id + "\",");
                clients.add(newClient);
                sendResponse(exchange, 200, newClient);
                System.out.println("✅ New client added: " + extractName(body));
            } else {
                sendResponse(exchange, 404, "{\"error\":\"Not Found\"}");
            }
        }
    }
    
    static class ContactHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            addCORSHeaders(exchange);
            
            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();
            
            if ("OPTIONS".equals(method)) {
                exchange.sendResponseHeaders(200, 0);
                exchange.close();
                return;
            }
            
            if ("GET".equals(method) && "/contact".equals(path)) {
                String response = "[" + String.join(",", contacts) + "]";
                sendResponse(exchange, 200, response);
            } else if ("POST".equals(method) && "/contact/add".equals(path)) {
                String body = readRequestBody(exchange);
                String id = String.valueOf(System.currentTimeMillis());
                String newContact = body.replaceFirst("\\{", "{\"id\":\"" + id + "\",");
                contacts.add(newContact);
                sendResponse(exchange, 200, "\"Contact submission received successfully!\"");
                System.out.println("📧 New contact submission: " + extractName(body));
            } else {
                sendResponse(exchange, 404, "{\"error\":\"Not Found\"}");
            }
        }
    }
    
    static class NewsletterHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            addCORSHeaders(exchange);
            
            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();
            
            if ("OPTIONS".equals(method)) {
                exchange.sendResponseHeaders(200, 0);
                exchange.close();
                return;
            }
            
            if ("GET".equals(method) && "/newsletter".equals(path)) {
                String response = "[" + String.join(",", newsletters) + "]";
                sendResponse(exchange, 200, response);
            } else if ("POST".equals(method) && "/newsletter/add".equals(path)) {
                String body = readRequestBody(exchange);
                String id = String.valueOf(System.currentTimeMillis());
                String newNewsletter = body.replaceFirst("\\{", "{\"id\":\"" + id + "\",");
                newsletters.add(newNewsletter);
                sendResponse(exchange, 200, "\"Successfully subscribed to newsletter!\"");
                System.out.println("📰 New newsletter subscription: " + extractEmail(body));
            } else {
                sendResponse(exchange, 404, "{\"error\":\"Not Found\"}");
            }
        }
    }
    
    private static void addCORSHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type, Authorization");
        exchange.getResponseHeaders().add("Content-Type", "application/json");
    }
    
    private static String readRequestBody(HttpExchange exchange) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(exchange.getRequestBody()));
        StringBuilder body = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            body.append(line);
        }
        return body.toString();
    }
    
    private static void sendResponse(HttpExchange exchange, int statusCode, String response) throws IOException {
        exchange.sendResponseHeaders(statusCode, response.getBytes().length);
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
    
    private static String extractName(String json) {
        try {
            int start = json.indexOf("\"name\":\"") + 8;
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        } catch (Exception e) {
            return "Unknown";
        }
    }
    
    private static String extractEmail(String json) {
        try {
            int start = json.indexOf("\"email\":\"") + 9;
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        } catch (Exception e) {
            return "Unknown";
        }
    }
}