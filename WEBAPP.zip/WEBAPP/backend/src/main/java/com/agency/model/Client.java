package com.agency.model;

import jakarta.validation.constraints.NotBlank;

public class Client {
    private String id;
    
    @NotBlank(message = "Client name is required")
    private String name;
    
    @NotBlank(message = "Description is required")
    private String description;
    
    private String designation;
    private String image;
    
    // Constructors
    public Client() {}
    
    public Client(String name, String description, String designation, String image) {
        this.name = name;
        this.description = description;
        this.designation = designation;
        this.image = image;
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
    
    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }
}