# 🚀 Quick Start Guide - Agency Website

## ✅ Backend is Now Working!

Your backend server is successfully running! Here's how to use your application:

### 1. Start the Backend Server

**Option A: Using the batch file (Recommended)**
```bash
cd backend
run.bat
```

**Option B: Manual start**
```bash
cd backend
javac SimpleAgencyServer.java
java SimpleAgencyServer
```

The server will start on: **http://localhost:8080**

### 2. Open the Frontend

**Landing Page:**
- Open `frontend/index.html` in your web browser
- This shows the public website with projects, clients, contact form

**Admin Panel:**
- Open `frontend/admin.html` in your web browser  
- This allows you to manage projects, clients, and view submissions

### 3. Test the Application

1. **View Projects & Clients**: The landing page should load with sample data
2. **Add New Project**: Go to admin panel → Projects → Add new project
3. **Add New Client**: Go to admin panel → Clients → Add new client
4. **Submit Contact Form**: Fill out the contact form on the landing page
5. **Subscribe to Newsletter**: Enter email in newsletter section

### 4. Features Working

✅ **Landing Page**
- Hero section with professional design
- Dynamic projects loading from backend
- Client testimonials with images
- Contact form with validation
- Newsletter subscription

✅ **Admin Panel**
- Add/view projects
- Add/view clients  
- View contact form submissions
- View newsletter subscribers

✅ **Backend API**
- GET/POST /projects
- GET/POST /clients
- GET/POST /contact
- GET/POST /newsletter
- CORS enabled for frontend

### 5. Sample Data Included

The backend starts with sample projects and clients so you can see the website working immediately.

### 6. Troubleshooting

**If backend won't start:**
- Make sure Java is installed (`java -version`)
- Check if port 8080 is available
- Run `backend/run.bat` for detailed error messages

**If frontend shows errors:**
- Make sure backend is running on http://localhost:8080
- Check browser console for error messages
- Verify CORS headers are working

### 7. Next Steps

- Customize the design in `frontend/css/style.css`
- Add more sample data by editing `SimpleAgencyServer.java`
- Deploy to a cloud service for production use

---

## 🎉 Your application is ready to use!

Open `frontend/index.html` and `frontend/admin.html` to see your professional agency website in action!